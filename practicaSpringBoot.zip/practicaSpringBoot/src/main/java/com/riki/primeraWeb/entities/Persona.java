package com.riki.primeraWeb.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name="tablaPersonas") // para poder cambiar el nombre de la tabla
@Data //para generar los getters y setters
@AllArgsConstructor //constructor con parámetros
@NoArgsConstructor // constructor sin parámetros
public class Persona {

   @Id
   //Hace que la ID sea incremental y no haya que añadirla manualmente
   @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String nombre;


    private int edad;
}
