package com.riki.primeraWeb.repository;

import com.riki.primeraWeb.entities.Persona;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

//Hereda de JpaRepository: Nombre ENTIDAD+REPOSITORY y especificas la enteidad en la etiqueta y el tipo de dato
@Repository //indicamos el estereotipo de Repository (Component)
public interface PersonaRepository extends JpaRepository<Persona,Long> {
}
