package com.riki.primeraWeb;

import com.riki.primeraWeb.repository.PersonaRepository;
import com.riki.primeraWeb.service.PersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PracticaSpringBoot {
//interface con el metodo run sirve para que un elemento (bean) se ejecute

	@Autowired // se encarga de inyectar Beans o elementos dentro del Contenedor
	private PersonaRepository pr;
	private PersonaRepository pri ;
	@Autowired
	private PersonaService ps;



	public static void main(String[] args) {
		SpringApplication.run(PracticaSpringBoot.class, args);



	}
/*
	@Override
	public void run(String... args) throws Exception {


		ps.crearPersona(new Persona(1L,"Paco",25));
		ps.crearPersona(new Persona(2L,"Pedro",27));
		ps.crearPersona(new Persona(3L,"Ricky",28));
		ps.crearPersona(new Persona(4L,"Hugo",19));
		ps.crearPersona(new Persona(5L,"Zentrillo",19));


		//cuenta el numero de personas con el metodo count()
		System.out.println("El numero de personas guardadas es "+ps.contarPersonas());
		//lista
		List<Persona> personas = pr.findAll();
		// for each del List personas de tipo Personas
		personas.forEach(p-> System.out.println("Nombre de la Persona : "+p.getNombre()));
	}*/


/*
		 Persona p = new Persona();
		p.setId(1L); //le seteamos 1 y la L porque es long (como float en unity 2.0f)
		p.setNombre("Ricardo");
		p.setEdad(25);
* */

}
