package com.riki.primeraWeb.service.impl;

import com.riki.primeraWeb.entities.Persona;
import com.riki.primeraWeb.repository.PersonaRepository;
import com.riki.primeraWeb.service.PersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonaServiceImpl implements PersonaService {

   @Autowired
   private PersonaRepository pr;


    @Override
    public List<Persona> obtenerTodas() {
        return pr.findAll();
    }

    @Override
    public Persona obtenerPorId(Long id) {
        return pr.findById(id).orElse(null); //busca una persona por su Id y sino me devuelve null
    }

    @Override
    public Persona crearPersona(Persona persona) {
        return pr.save(persona);
    }

    @Override
    public Persona actualizarPersona(Long id, Persona persona) {
       Persona pbbdd = pr.findById(id).orElse(null);

        if (pbbdd != null){

        pbbdd.setNombre(persona.getNombre());
        pbbdd.setEdad(persona.getEdad());

        return pr.save(pbbdd);
        }
      return null;
    }

    @Override
    public void eliminarPersona(Long id) {
        pr.deleteById(id);
    }

    @Override
    public long contarPersonas() {
        return pr.count();
    }


}
