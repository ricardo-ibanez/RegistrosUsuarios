package com.riki.primeraWeb.controller;



import com.riki.primeraWeb.entities.Persona;
import com.riki.primeraWeb.service.PersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/personas")
public class PersonaController {

    @Autowired
    private PersonaService ps;

    //Para pasar algo al HTML hay que hacerlo como MODELO
    // (se utiliza para transmitir objetos y datos del controlador a la vista)


    @GetMapping
    public String listarPersonas(Model model){

        List<Persona> p =ps.obtenerTodas();
        model.addAttribute("personasLista",p);
        //te dirige al html que se llame listar de la carpeta templates
        return "listar";

    }

    @GetMapping("/nueva")
    public String mostrarFormularioNuevaPersona(Model model){
        //se le añadira un nuevo objeto Persona con lo que se digite en el formulario
        //se le añade como un nombre o "id" y un objeto que queramos usar en el template (u otro sitio)
        model.addAttribute("persona",new Persona());
        model.addAttribute("accion","/personas/nueva");

        return "formulario";
    }

    @PostMapping("/nueva")
    //@ModelAtributte empaqueta como modelo los campos del formulario a un MODELO de PERSONA para pode usar el método save()
    public String guardarPersona(@ModelAttribute Persona persona){
        ps.crearPersona(persona);

        return "redirect:/personas"; // Redirige la URL de redirección
    }

    @GetMapping("/editar/{id}")
    //@PathVariable permite pasarle varibles a la ruta URL
    // //@ModelAtributte empaqueta como modelo los campos del formulario a un MODELO de PERSONA para pode usar el método save()
    //Model model es para parselo a la vista
    public String mostrarFormularioEditarPersona(@PathVariable Long id, @ModelAttribute Persona persona, Model model){
        //se le añadira un nuevo objeto Persona con lo que se digite en el formulario
        //se le añade como un nombre o "id" y un objeto que queramos usar en el template (u otro sitio)
        model.addAttribute("persona",persona);
        model.addAttribute("accion","/personas/editar/"+id);

        return "formulario";
    }

    @PostMapping("/editar/{id}")
    public String actualizarPersona(@PathVariable Long id, @ModelAttribute Persona persona){
        // Actualizar la persona en la base de datos utilizando el ID proporcionado
        ps.actualizarPersona(id, persona);
        return "redirect:/personas";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarPersona(@PathVariable Long id){
        ps.eliminarPersona(id);
        return "redirect:/personas";
    }
}
